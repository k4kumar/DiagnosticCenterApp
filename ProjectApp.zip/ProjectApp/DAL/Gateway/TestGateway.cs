﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using ProjectApp.DAL.Model;

namespace ProjectApp.DAL.Gateway
{
    public class TestGateway:Gateway
    {
        public int SaveTest(TestNameModel test)
        {

            Query = "INSERT INTO tbl_Test(TestName,Fee,TypeId) VALUES('" + test.TestName + "','" + test.Fee + "','" + test.TypeId + "')";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();

            int rowAffected = Command.ExecuteNonQuery();

            Connection.Close();

            return rowAffected;
        }
        public List<TestNameModel> GetAllTest()
        {
            Query = "SELECT * FROM tbl_Test";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();

            List<TestNameModel> tests = new List<TestNameModel>();

            Reader = Command.ExecuteReader();


            while (Reader.Read())
            {
                TestNameModel test = new TestNameModel();
                test.TestName = Reader["TestName"].ToString();
                test.Fee = Convert.ToDecimal(Reader["Fee"]);
                test.TypeId = (int)Reader["TypeId"];

                tests.Add(test);
            }

            Reader.Close();
            Connection.Close();

            return tests;



        }

        public List<TestNameModel> GetAllTestbyid(int id)
        {
            Query = "SELECT * FROM tbl_Test where tbl_Test.Id= '"+id+"' ";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();

            List<TestNameModel> tests = new List<TestNameModel>();

            Reader = Command.ExecuteReader();


            while (Reader.Read())
            {
                TestNameModel test = new TestNameModel();
                test.TestName = Reader["TestName"].ToString();
                test.Fee = Convert.ToDecimal(Reader["Fee"]);
                test.TypeId = (int)Reader["TypeId"];

                tests.Add(test);
            }

            Reader.Close();
            Connection.Close();

            return tests;


        }

        public  List<TestModelVM> GetAllTestVM()
        {
            Query = "SELECT *FROM TsetWithType";

            Command = new SqlCommand(Query, Connection);
            Connection.Open();

            List<TestModelVM> tests = new List<TestModelVM>();

            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                TestModelVM test = new TestModelVM();
                test.TestName = Reader["TestName"].ToString();
                test.Fee = (Decimal)Reader["Fee"];
                test.TypeName = Reader["TypeName"].ToString();

                tests.Add(test);

            }
            Reader.Close();
            Connection.Close();

            return tests;

        }
    }
}