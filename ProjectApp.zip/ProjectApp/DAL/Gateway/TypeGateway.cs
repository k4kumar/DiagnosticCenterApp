﻿using ProjectApp.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace ProjectApp.DAL.Gateway
{
    public class TypeGateway:Gateway
    {
        public int Save(TypeNameModel type)
        {


            Query = "INSERT INTO tbl_Type VALUES('" + type.TypeName + "')";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();

            int rowAffected = Command.ExecuteNonQuery();

            Connection.Close();

            return rowAffected;
        }

        public List<TypeNameModel> GetAllTypes()
        {
            Query = "SELECT * FROM tbl_Type";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();

            List<TypeNameModel> types = new List<TypeNameModel>();

            Reader = Command.ExecuteReader();


            while (Reader.Read())
            {
                TypeNameModel type = new TypeNameModel();
                type.TypeName = Reader["TypeName"].ToString();
                type.Id =(Int32) Reader["Id"];
                types.Add(type);
            }

            Reader.Close();
            Connection.Close();

            return types;


        }

    }
}