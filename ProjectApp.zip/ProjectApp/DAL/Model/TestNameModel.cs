﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectApp.DAL.Model
{
    public class TestNameModel
    {
        public int Id { get; set; }
        public string TestName { get; set; }
        public decimal Fee { get; set; }
        public int TypeId { get; set; }
        public DateTime Date_today { get; set; }
    }
}