﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectApp.DAL.Model
{
    public class PersonalInformationModel
    {
        public int Id { get; set; }

        public string PatientName { get; set; }

        public string BirthDate { get; set; }
        public string MobileNo { get; set; }

    }
}