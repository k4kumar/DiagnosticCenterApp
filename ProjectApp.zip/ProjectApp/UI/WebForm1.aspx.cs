﻿using Microsoft.Reporting.WebForms;
using ProjectApp.BLL;
using ProjectApp.DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectApp.UI
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Testmanager aTestManager = new Testmanager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ReportViewer1.ProcessingMode = ProcessingMode.Local;
                ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/Report2.rdlc");
                List<TestModelVM> types = aTestManager.GetAllTestVM();
                IEnumerable<TestModelVM> ie;
                ie = types.AsQueryable();
                ReportDataSource datasource = new ReportDataSource("DataSet1", ie);
                ReportViewer1.LocalReport.DataSources.Clear();
                ReportViewer1.LocalReport.DataSources.Add(datasource);
            }
        }
    }
}